<?php
session_start();
header('Content-Type: application/json');
require 'db.php';

// 👉 模拟登录（你可以以后换成真实登录）
$isAdmin = $_SESSION['isAdmin'] ?? false; // 现在默认true方便测试
$userID = $_SESSION['userID'] ?? 1;

if (!$isAdmin) {
    echo json_encode(['error' => 'Not authorized']);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$text = trim($data['text'] ?? '');
$author = trim($data['author'] ?? '');

if (!$text || !$author) {
    echo json_encode(['error' => 'All fields required']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO quotes (quoteText, author, activeDate, createdBy)
        VALUES (?, ?, CURDATE(), ?)
    ");
    $stmt->execute([$text, $author, $userID]);

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>